# BSD adapter

**Current status:** detection/architecture normalization implemented; FreeBSD, OpenBSD, NetBSD and DragonFly not tested in this build. Require Python 3.10+, probe available utilities and filesystem semantics, and no-op when a capability is absent. Do not assume GNU coreutils or Linux paths.
