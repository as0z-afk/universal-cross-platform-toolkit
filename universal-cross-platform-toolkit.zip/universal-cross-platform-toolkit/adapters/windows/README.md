# Windows adapter

**Current status:** detection implemented; no system mutator included; native execution not tested in this build. Use Python 3.10+ and `run.ps1` or `run.bat`. Do not write to the registry, browser profiles, startup folders, or Program Files without a separate reviewed feature and explicit consent. Preserve Windows Defender, TLS validation, browser sandboxing, and UAC defaults.
