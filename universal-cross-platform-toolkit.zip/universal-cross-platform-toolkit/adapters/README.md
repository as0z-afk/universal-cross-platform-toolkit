# OS adapter contract

Adapters are opt-in, capability-driven extensions. The current release intentionally implements OS discovery only; it does not write system settings or require package managers. Each target directory explains current limits and the requirements for any future adapter. Unsupported capabilities must return a clear no-op/diagnostic, never guess a command or silently escalate privileges.
