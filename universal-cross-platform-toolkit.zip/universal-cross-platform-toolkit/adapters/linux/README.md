# Linux adapter

**Current status:** detection implemented; host CLI sandbox-tested on Linux. No distribution-specific tuning commands are run. Package manager, display stack, init system, and browser capabilities must be probed separately; never assume apt, systemd, GNOME, Wayland, or one path layout.
