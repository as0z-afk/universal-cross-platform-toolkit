# ChromeOS adapter

**Current status:** best-effort marker/`lsb-release` detection; native and Crostini modes not tested. ChromeOS may expose Linux inside Crostini. `UBT_TARGET_OS=chromeos` is a reporting hint, not proof of a native environment or permission. No host ChromeOS settings are changed; manage only files owned by the current container/user.
