# macOS adapter

**Current status:** detection implemented; runtime not tested in this build. Respect user consent, System Integrity Protection, sandbox boundaries, Gatekeeper and browser profile protection. Do not edit browser flags or managed preferences automatically. Use per-user managed paths and test atomic replace behavior on the target filesystem.
