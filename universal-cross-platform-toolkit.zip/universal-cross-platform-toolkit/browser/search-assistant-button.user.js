// ==UserScript==
// @name         Universal Toolkit — Search Assistant Button
// @namespace    https://example.invalid/universal-toolkit
// @version      1.0.0
// @description  Adds an explicit button to open the current search query in Perplexity; no automatic redirect or background request.
// @match        https://www.google.com/search*
// @match        https://duckduckgo.com/*
// @match        https://www.bing.com/search*
// @match        https://search.yahoo.com/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==
(() => {
  'use strict';
  let lastHref = location.href;
  const addButton = () => {
    if (!document.body || document.getElementById('ubt-search-assistant')) return;
    const url = new URL(location.href);
    const query = url.searchParams.get('q') || url.searchParams.get('p') ||
      (document.querySelector('input[name="q"],input[name="p"]') || {}).value || '';
    if (!query.trim()) return;
    const button = document.createElement('button');
    button.id = 'ubt-search-assistant';
    button.type = 'button';
    button.textContent = 'Open query in Perplexity';
    button.style.cssText = 'position:fixed;right:12px;top:12px;z-index:2147483000;padding:8px 12px;border-radius:9px;border:1px solid #1aa88a;background:#0b1016;color:#dce8d8;font:13px system-ui;cursor:pointer';
    button.addEventListener('click', () => {
      const target = new URL('https://www.perplexity.ai/search');
      target.searchParams.set('q', query);
      window.open(target.href, '_blank', 'noopener,noreferrer');
    });
    document.body.appendChild(button);
  };
  setTimeout(addButton, 600);
  const observer = new MutationObserver(() => {
    if (location.href !== lastHref) {
      lastHref = location.href;
      document.getElementById('ubt-search-assistant')?.remove();
      setTimeout(addButton, 250);
    } else if (!document.getElementById('ubt-search-assistant')) addButton();
  });
  if (document.body) observer.observe(document.body, {childList:true,subtree:true});
  window.addEventListener('pagehide', () => observer.disconnect(), {once:true});
})();
