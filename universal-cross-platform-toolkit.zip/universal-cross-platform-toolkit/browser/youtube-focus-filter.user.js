// ==UserScript==
// @name         Universal Toolkit — YouTube Focus Filter
// @namespace    https://example.invalid/universal-toolkit
// @version      1.0.0
// @description  Optional local title/Shorts filter. Reversible; no network calls or account access.
// @match        https://www.youtube.com/*
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_addStyle
// @run-at       document-idle
// ==/UserScript==
(() => {
  'use strict';
  const KEY = 'ubt-focus-v1';
  const DEFAULTS = {
    enabled: false,
    hideShorts: true,
    filterNonLatinTitles: false,
    terms: ['celebrity gossip', 'roasting', 'vulgar', 'prank compilation', 'family vlog', 'clickbait', 'get rich quick', 'crypto pump', 'mukbang', 'shopping haul', 'viral fails', 'reaction video', 'tea spill', 'exposed', 'cancelled', 'zodiac', 'horoscope', 'manifestation', 'meme compilation', 'funny fails', 'tiktok compilation', 'gaming highlights', 'twitch clips']
  };
  const load = () => {
    try { return Object.assign({}, DEFAULTS, GM_getValue(KEY, {})); }
    catch (_) { return Object.assign({}, DEFAULTS); }
  };
  let state = load();
  let timer = null;
  const CARD_SELECTORS = [
    'ytd-rich-item-renderer', 'ytd-video-renderer', 'ytd-compact-video-renderer',
    'ytd-grid-video-renderer', 'yt-lockup-view-model'
  ].join(',');
  const SHORTS_SELECTORS = 'ytd-reel-item-renderer, ytd-reel-shelf-renderer';
  GM_addStyle(`
    #ubt-focus-panel{position:fixed;right:12px;bottom:12px;z-index:2147483600;background:#0b1016;color:#dce8d8;border:1px solid #1aa88a;border-radius:12px;padding:10px;max-width:270px;font:12px/1.5 system-ui;box-shadow:0 8px 24px #0008}
    #ubt-focus-panel button{background:#14201d;color:#dce8d8;border:1px solid #1aa88a;border-radius:7px;padding:5px 8px;margin:3px;cursor:pointer}
    #ubt-focus-panel button:focus-visible{outline:2px solid #b8d070;outline-offset:2px}
    #ubt-focus-panel .ubt-status{color:#b8d070;margin:3px 0 5px}
    [data-ubt-hidden="1"]{display:none!important}
    @media(prefers-reduced-motion:reduce){#ubt-focus-panel *{scroll-behavior:auto!important;transition:none!important}}
  `);
  function save() { try { GM_setValue(KEY, state); } catch (_) {} }
  function restore() {
    document.querySelectorAll('[data-ubt-hidden="1"]').forEach(el => { el.removeAttribute('data-ubt-hidden'); });
  }
  function nonLatinLetterRatio(value) {
    try {
      const letters = value.match(/\p{L}/gu) || [];
      if (!letters.length) return 0;
      const nonLatin = letters.filter(ch => !/\p{Script=Latin}/u.test(ch)).length;
      return nonLatin / letters.length;
    } catch (_) { return 0; }
  }
  function scan() {
    if (!document.body) return;
    if (!state.enabled) { restore(); updatePanel(); return; }
    if (state.hideShorts) document.querySelectorAll(SHORTS_SELECTORS).forEach(el => el.setAttribute('data-ubt-hidden','1'));
    else document.querySelectorAll(SHORTS_SELECTORS).forEach(el => el.removeAttribute('data-ubt-hidden'));
    const terms = (Array.isArray(state.terms) ? state.terms : DEFAULTS.terms)
      .map(x => String(x).trim().toLocaleLowerCase()).filter(Boolean).slice(0,100);
    document.querySelectorAll(CARD_SELECTORS).forEach(card => {
      const text = (card.innerText || card.textContent || '').slice(0,5000).toLocaleLowerCase();
      const keywordMatch = terms.some(term => text.includes(term));
      const scriptMatch = state.filterNonLatinTitles && nonLatinLetterRatio(text) > 0.12;
      if (keywordMatch || scriptMatch) card.setAttribute('data-ubt-hidden','1');
      else card.removeAttribute('data-ubt-hidden');
    });
    updatePanel();
  }
  function schedule() { if (timer) clearTimeout(timer); timer = setTimeout(scan, 220); }
  function panel() {
    let root = document.getElementById('ubt-focus-panel');
    if (root) return root;
    root = document.createElement('section'); root.id='ubt-focus-panel'; root.setAttribute('aria-label','Universal Toolkit focus filter');
    const title=document.createElement('strong'); title.textContent='Focus filter'; root.appendChild(title);
    const status=document.createElement('div'); status.className='ubt-status'; status.id='ubt-focus-status'; root.appendChild(status);
    const make=(label,action)=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.addEventListener('click',action);root.appendChild(b);return b;};
    make('Enable / disable',()=>{state.enabled=!state.enabled;save();schedule();});
    make('Shorts on / off',()=>{state.hideShorts=!state.hideShorts;save();schedule();});
    make('Script heuristic on / off',()=>{state.filterNonLatinTitles=!state.filterNonLatinTitles;save();schedule();});
    make('Edit terms',()=>{
      const current=(state.terms||DEFAULTS.terms).join(', ');
      const value=prompt('Comma-separated title terms to hide. Leave blank to use no keyword rules:',current);
      if(value!==null){state.terms=value.split(',').map(x=>x.trim()).filter(Boolean).slice(0,100);save();schedule();}
    });
    make('Restore hidden cards',()=>{restore();state.enabled=false;save();updatePanel();});
    make('Close',()=>root.remove());
    document.body.appendChild(root); updatePanel(); return root;
  }
  function updatePanel() {
    const status=document.getElementById('ubt-focus-status');
    if(status){const hidden=document.querySelectorAll('[data-ubt-hidden="1"]').length;const next=`Filtering ${state.enabled?'ON':'OFF'} · Shorts ${state.hideShorts?'hidden':'shown'} · script heuristic ${state.filterNonLatinTitles?'ON':'OFF'} · ${hidden} hidden · ${Array.isArray(state.terms)?state.terms.length:0} terms`;if(status.textContent!==next)status.textContent=next;}
  }
  const observer = new MutationObserver(schedule);
  const boot = () => { panel(); if (document.documentElement) observer.observe(document.documentElement,{childList:true,subtree:true}); schedule(); };
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot,{once:true}); else boot();
  window.addEventListener('pagehide',()=>{observer.disconnect();if(timer)clearTimeout(timer);},{once:true});
})();
