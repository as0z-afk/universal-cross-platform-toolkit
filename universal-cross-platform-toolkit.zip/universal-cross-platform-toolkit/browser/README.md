# Optional browser helpers

Both scripts are opt-in, self-hosted files. Read each source before adding it to a userscript manager. Neither script requires a companion service, performs a background network fetch, changes browser security flags, injects cookies, disables access controls, or edits browser profiles.

- `youtube-focus-filter.user.js`: only matches YouTube HTTPS pages; title keyword filtering is off by default. The user can toggle it, change words, hide/show Shorts, toggle an optional non-Latin-script ratio heuristic (disabled by default), and restore cards. That heuristic is not language detection and can hide multilingual items; it is not enabled by default. It is a DOM presentation aid, not a network blocker or a classifier of truth.
- `search-assistant-button.user.js`: adds a button on a few search result pages. It does not redirect automatically; only a user click opens the query in Perplexity. Search text is included in that destination URL, so do not use the button for confidential queries.

Remove scripts from the userscript manager to uninstall them. Site DOMs and selectors change over time, so retest after browser/site updates. Do not use scripts to bypass paywalls or authentication, or to collect page/account data.
