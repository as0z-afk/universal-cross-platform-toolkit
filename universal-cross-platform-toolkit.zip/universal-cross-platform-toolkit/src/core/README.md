# Core architecture map

The runnable core is packaged in `ubtoolkit/` so it can be used both from a cloned repository and as a Python package. Responsibilities:

- `platform_info.py`: normalized OS/architecture/capability discovery; never applies settings.
- `paths.py`: relative path validation, symlink rejection, atomic writes and JSON state helpers.
- `updater.py`: manifest validation, HTTPS-only bounded download, hashes, transaction backups and guarded rollback.
- `cli.py`: human-facing commands, exports and preference management.

This directory documents the logical `src/core/` grouping without maintaining a second, divergent implementation. Shared code belongs in `ubtoolkit/`.
