import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from ubtoolkit.updater import apply_manifest, dry_run, UpdateError, rollback_latest, validate_manifest
from ubtoolkit.paths import sha256_bytes

class UpdaterTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=Path(self.tmp.name)
        self.root=self.base/'root';self.state=self.base/'state';self.payload=b'approved text data\n'
        self.manifest={'schema_version':1,'version':'test-1','files':[{'path':'features/example.txt','operation':'install','feature':'example','url':'https://updates.example.test/example.txt','sha256':sha256_bytes(self.payload)}]}
        self.raw=(json.dumps(self.manifest,separators=(',',':'))+'\n').encode();self.digest=sha256_bytes(self.raw)
    def tearDown(self): self.tmp.cleanup()
    def downloader(self,url,limit):
        self.assertTrue(url.startswith('https://'));self.assertGreaterEqual(limit,len(self.payload));return self.payload
    def test_install_and_rollback(self):
        msg=apply_manifest(self.manifest,self.raw,self.digest,self.root,self.state,self.downloader)
        target=self.root/'managed'/'features'/'example.txt'
        self.assertIn('Applied 1',msg);self.assertEqual(target.read_bytes(),self.payload)
        self.assertEqual(rollback_latest(self.root,self.state),next((self.state/'backups').iterdir()).name)
        self.assertFalse(target.exists())
    def test_manifest_pin_required(self):
        with self.assertRaises(UpdateError):apply_manifest(self.manifest,self.raw,None,self.root,self.state,self.downloader)
    def test_manifest_digest_mismatch(self):
        with self.assertRaises(UpdateError):apply_manifest(self.manifest,self.raw,'0'*64,self.root,self.state,self.downloader)
    def test_payload_hash_mismatch(self):
        def bad(url,limit):return b'wrong'
        with self.assertRaises(UpdateError):apply_manifest(self.manifest,self.raw,self.digest,self.root,self.state,bad)
        self.assertFalse((self.root/'managed'/'features'/'example.txt').exists())
    def test_http_url_rejected(self):
        m=json.loads(self.raw);m['files'][0]['url']='http://updates.example.test/x'
        with self.assertRaises(UpdateError):validate_manifest(m)
    def test_path_traversal_rejected(self):
        m=json.loads(self.raw);m['files'][0]['path']='../../escape'
        with self.assertRaises(UpdateError):validate_manifest(m)
    def test_private_update_host_rejected(self):
        m=json.loads(self.raw);m['files'][0]['url']='https://127.0.0.1/private'
        with self.assertRaises(UpdateError):validate_manifest(m)
    def test_duplicate_paths_rejected(self):
        m=json.loads(self.raw);m['files'].append(dict(m['files'][0]))
        with self.assertRaises(UpdateError):validate_manifest(m)
    def test_credential_query_rejected(self):
        m=json.loads(self.raw);m['files'][0]['url']='https://updates.example.test/file?token=secret'
        with self.assertRaises(UpdateError):validate_manifest(m)
    def test_remove_unowned_file_is_refused(self):
        removal={'schema_version':1,'version':'remove-unowned','files':[{'path':'features/unowned.txt','operation':'remove','feature':'example'}]}
        raw=(json.dumps(removal,separators=(',',':'))+'\n').encode()
        with self.assertRaises(UpdateError):apply_manifest(removal,raw,sha256_bytes(raw),self.root,self.state,self.downloader)
    def test_unknown_file_not_overwritten(self):
        target=self.root/'managed'/'features'/'example.txt';target.parent.mkdir(parents=True);target.write_bytes(b'user data')
        with self.assertRaises(UpdateError):apply_manifest(self.manifest,self.raw,self.digest,self.root,self.state,self.downloader)
        self.assertEqual(target.read_bytes(),b'user data')
    def test_rollback_refuses_user_edit(self):
        apply_manifest(self.manifest,self.raw,self.digest,self.root,self.state,self.downloader)
        target=self.root/'managed'/'features'/'example.txt';target.write_bytes(b'user changed it')
        with self.assertRaises(UpdateError):rollback_latest(self.root,self.state)
        self.assertEqual(target.read_bytes(),b'user changed it')
    def test_repair_restores_missing_managed_file(self):
        apply_manifest(self.manifest,self.raw,self.digest,self.root,self.state,self.downloader)
        target=self.root/'managed'/'features'/'example.txt';target.unlink()
        result=apply_manifest(self.manifest,self.raw,self.digest,self.root,self.state,self.downloader)
        self.assertIn('Applied 1',result)
        self.assertEqual(target.read_bytes(),self.payload)
    def test_empty_payload_is_rollback_safe(self):
        empty=b''
        m={'schema_version':1,'version':'empty-payload','files':[{'path':'features/empty.txt','operation':'install','feature':'empty','url':'https://updates.example.test/empty.txt','sha256':sha256_bytes(empty)}]}
        raw=(json.dumps(m,separators=(',',':'))+'\n').encode()
        apply_manifest(m,raw,sha256_bytes(raw),self.root,self.state,lambda url,limit:empty)
        target=self.root/'managed'/'features'/'empty.txt';self.assertEqual(target.read_bytes(),b'')
        rollback_latest(self.root,self.state);self.assertFalse(target.exists())
    def test_update_then_rollback_restores_previous_bytes(self):
        apply_manifest(self.manifest,self.raw,self.digest,self.root,self.state,self.downloader)
        target=self.root/'managed'/'features'/'example.txt'
        old=b'updated approved text\n'
        update={'schema_version':1,'version':'test-2','files':[{'path':'features/example.txt','operation':'install','feature':'example','url':'https://updates.example.test/example.txt','sha256':sha256_bytes(old)}]}
        raw=(json.dumps(update,separators=(',',':'))+'\n').encode()
        apply_manifest(update,raw,sha256_bytes(raw),self.root,self.state,lambda url,limit:old)
        self.assertEqual(target.read_bytes(),old)
        rollback_latest(self.root,self.state)
        self.assertEqual(target.read_bytes(),self.payload)
    def test_remove_only_tracked_files(self):
        apply_manifest(self.manifest,self.raw,self.digest,self.root,self.state,self.downloader)
        target=self.root/'managed'/'features'/'example.txt'
        removal={'schema_version':1,'version':'test-remove','files':[{'path':'features/example.txt','operation':'remove','feature':'example'}]}
        raw=(json.dumps(removal,separators=(',',':'))+'\n').encode()
        apply_manifest(removal,raw,sha256_bytes(raw),self.root,self.state,self.downloader)
        self.assertFalse(target.exists())
    def test_empty_dry_run(self):
        self.assertTrue(dry_run({'schema_version':1,'version':'empty','files':[]},self.root))
if __name__=='__main__':unittest.main()
