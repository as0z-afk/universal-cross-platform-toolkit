import json
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class DataTests(unittest.TestCase):
    def test_resource_urls_are_unique_https(self):
        d=json.loads((ROOT/'data/resources.json').read_text())
        urls=[x['url'] for x in d['bookmarks']]
        self.assertEqual(len(urls),len(set(u.casefold() for u in urls)))
        self.assertTrue(all(u.startswith('https://') for u in urls))
    def test_extension_snapshot_is_caveated(self):
        d=json.loads((ROOT/'data/extensions-curated.json').read_text())
        self.assertGreater(len(d['records']),0)
        self.assertIn('not live-rechecked',d['provenance'])
    def test_site_is_standalone(self):
        text=(ROOT/'web/index.html').read_text()
        self.assertIn('const DATA=',text)
        self.assertNotIn('fetch(',text)
        self.assertNotIn('https://fonts.googleapis.com',text)
if __name__=='__main__':unittest.main()
