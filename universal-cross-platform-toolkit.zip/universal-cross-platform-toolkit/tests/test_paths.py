import tempfile
import unittest
from pathlib import Path
from ubtoolkit.paths import checked_relative_path, safe_join, UnsafePathError, atomic_write

class PathTests(unittest.TestCase):
    def test_valid_path(self):
        self.assertEqual(str(checked_relative_path('features/demo.json')),'features/demo.json')
    def test_reject_escapes(self):
        for raw in ('../escape','/absolute','a/../b','a/./b','a//b','C:/Windows','a\\b','state/installed.json',''):
            with self.subTest(raw=raw), self.assertRaises(UnsafePathError): checked_relative_path(raw)
    def test_symlink_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d)/'managed'; base.mkdir(); target=Path(d)/'outside';target.mkdir()
            try:
                (base/'link').symlink_to(target,target_is_directory=True)
            except OSError:
                self.skipTest('symlink creation not permitted on this host')
            with self.assertRaises(UnsafePathError): safe_join(base,'link/file')
    def test_atomic_write(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'a'/'b.bin';atomic_write(p,b'new');self.assertEqual(p.read_bytes(),b'new')
if __name__=='__main__':unittest.main()
