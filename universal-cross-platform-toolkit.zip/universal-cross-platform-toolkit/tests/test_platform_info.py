import unittest
from ubtoolkit.platform_info import normalize_arch, detect_os, system_report

class PlatformInfoTests(unittest.TestCase):
    def test_x86_aliases(self):
        self.assertEqual(normalize_arch('AMD64'),'x86_64')
        self.assertEqual(normalize_arch('i386'),'i686')
        self.assertEqual(normalize_arch('i686'),'i686')
    def test_arm_is_not_aarch64(self):
        self.assertEqual(normalize_arch('armv7l'),'arm32')
        self.assertEqual(normalize_arch('arm64'),'aarch64')
    def test_other_aliases(self):
        self.assertEqual(normalize_arch('powerpc64le'),'ppc64le')
        self.assertEqual(normalize_arch('unknown-arch'),'unknown-arch')
    def test_report_has_no_home_path(self):
        report=system_report()
        self.assertIn('architecture',report)
        self.assertNotIn('home',json_repr(report).lower())

def json_repr(x):
    import json
    return json.dumps(x)
if __name__=='__main__':unittest.main()
