#!/usr/bin/env python3
"""Generate or verify MANIFEST.json with SHA-256 hashes; excludes itself."""
from pathlib import Path
import argparse,hashlib,json,sys
root=Path(__file__).resolve().parents[1]
manifest_path=root/'MANIFEST.json'
def enumerate_files():
    files=[]
    for p in sorted(root.rglob('*')):
        if not p.is_file(): continue
        rel=p.relative_to(root).as_posix()
        if rel=='MANIFEST.json' or '.git' in p.parts or '__pycache__' in p.parts: continue
        payload=p.read_bytes()
        files.append({'path':rel,'size_bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()})
    return files
parser=argparse.ArgumentParser()
parser.add_argument('--verify',action='store_true',help='verify listed hashes and detect unlisted files')
args=parser.parse_args()
if not args.verify:
    files=enumerate_files()
    manifest={'schema_version':1,'generated_by':'scripts/build_manifest.py','note':'MANIFEST.json intentionally excludes its own digest to avoid recursive self-hashing.','files':files}
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'Wrote {len(files)} file hashes to MANIFEST.json')
    raise SystemExit(0)
try: old=json.loads(manifest_path.read_text(encoding='utf-8'))
except Exception as exc: print(f'MANIFEST ERROR: cannot read MANIFEST.json: {exc}');raise SystemExit(1)
listed={x.get('path'):x for x in old.get('files',[]) if isinstance(x,dict) and isinstance(x.get('path'),str)}
current=enumerate_files();now={x['path']:x for x in current}
errors=[]
for rel,entry in listed.items():
    actual=now.get(rel)
    if actual is None: errors.append(f'missing file: {rel}')
    elif actual['sha256']!=entry.get('sha256') or actual['size_bytes']!=entry.get('size_bytes'): errors.append(f'hash/size mismatch: {rel}')
for rel in sorted(set(now)-set(listed)): errors.append(f'unlisted file: {rel}')
if errors:
    print('MANIFEST VERIFY FAILED')
    for e in errors: print(' -',e)
    raise SystemExit(1)
print(f'MANIFEST OK — {len(listed)} files verified; MANIFEST.json excludes itself.')
