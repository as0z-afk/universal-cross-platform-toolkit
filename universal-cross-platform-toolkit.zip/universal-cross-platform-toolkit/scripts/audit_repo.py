#!/usr/bin/env python3
"""Offline repository content/safety audit; no network access."""
from pathlib import Path
import json, re, sys, urllib.parse
ROOT=Path(__file__).resolve().parents[1]
errors=[]; warnings=[]
def fail(msg): errors.append(msg)
for rel in ('data/resources.json','data/extensions-curated.json','data/features.json','config/content-filters.json','schemas/update-manifest.schema.json'):
    p=ROOT/rel
    try: json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: fail(f'{rel}: invalid/missing JSON ({e})')
try:
    data=json.loads((ROOT/'data/resources.json').read_text(encoding='utf-8'))
    urls=[]
    for item in data['bookmarks']:
        u=item.get('url',''); p=urllib.parse.urlsplit(u)
        if p.scheme!='https' or not p.hostname: fail(f'non-HTTPS resource URL: {u}')
        urls.append(u.casefold())
    if len(urls)!=len(set(urls)): fail('duplicate resource URLs')
    if data != json.loads((ROOT/'ubtoolkit/data/resources.json').read_text(encoding='utf-8')): fail('package resource copy is out of sync')
    for name in ('resources.json','extensions-curated.json','features.json'):
        if json.loads((ROOT/'data'/name).read_text(encoding='utf-8')) != json.loads((ROOT/'ubtoolkit/data'/name).read_text(encoding='utf-8')): fail(f'package data copy is out of sync: {name}')
except Exception as e: fail(f'resource data audit failed: {e}')
try:
    ext=json.loads((ROOT/'data/extensions-curated.json').read_text(encoding='utf-8'))
    for item in ext['records']:
        u=item.get('url','')
        if u and urllib.parse.urlsplit(u).scheme!='https': fail(f'non-HTTPS extension URL: {u}')
    if 'not live-rechecked' not in ext.get('provenance',''): fail('extension dataset lacks live-check caveat')
except Exception as e: fail(f'extension data audit failed: {e}')
site=(ROOT/'web/index.html').read_text(encoding='utf-8')
for needle in ('<script src=', '<link href="http', '@import', 'fetch(', 'XMLHttpRequest', 'navigator.sendBeacon'):
    if needle.lower() in site.lower(): fail(f'offline site contains external-request indicator: {needle}')
# Do not scan docs/tests, where insecure flags are discussed as prohibited examples.
for rel in ('ubtoolkit','browser','scripts'):
    for p in (ROOT/rel).rglob('*'):
        if not p.is_file() or p.suffix not in {'.py','.js','.sh','.ps1','.bat'} or p.name == 'audit_repo.py': continue
        text=p.read_text(encoding='utf-8',errors='replace').lower()
        for forbidden in ('--no-sandbox','--disable-web-security','--ignore-certificate-errors','--remote-debugging-port=9222','--disable-ipc-flooding-protection','auth_cookie_injection_method'):
            if forbidden in text: fail(f'unsafe browser/auth pattern in executable source {p.relative_to(ROOT)}: {forbidden}')
excluded_names=('history-export','search-history','watch-history','conversation_markdown_final','cookies.sqlite','login data')
for p in ROOT.rglob('*'):
    rel=p.relative_to(ROOT).as_posix().lower()
    if any(x in rel for x in excluded_names): fail(f'private/export artifact path should not ship: {rel}')
if errors:
    print('AUDIT FAILED')
    for e in errors: print(' -',e)
    sys.exit(1)
print('AUDIT OK — JSON parses, resource URLs are unique HTTPS, extension links have caveats, offline UI has no network API, and forbidden patterns are absent from executable source.')
if warnings:
    for w in warnings: print('WARNING:',w)
