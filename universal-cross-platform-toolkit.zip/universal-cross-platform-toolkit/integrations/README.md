# Optional integrations

No network account or browser account is connected by this repository. Third-party integrations may be added only as explicit opt-ins with pinned versions, a license review, least privilege, a privacy explanation and offline fallback. Remote code must not be downloaded and executed by the updater. See `docs/THIRD_PARTY_BOUNDARIES.md` for informational third-party references carried over from the supplied materials.
