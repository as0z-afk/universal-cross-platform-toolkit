"""Hash-pinned, staged updater for data files only. Never executes downloaded content."""
from __future__ import annotations
import hashlib
import ipaddress
import json
import os
import re
import shutil
import urllib.parse
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable
from .paths import UnsafePathError, atomic_write, read_json, safe_join, sha256_bytes, write_json_atomic

HEX64 = re.compile(r"^[0-9a-fA-F]{64}$")
FEATURE = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
MAX_FILE_BYTES = 10 * 1024 * 1024
MAX_TOTAL_BYTES = 25 * 1024 * 1024
MAX_MANIFEST_BYTES = 2 * 1024 * 1024


class UpdateError(RuntimeError):
    pass


def validate_https_url(url: str):
    parsed = urllib.parse.urlsplit(url or "")
    host = (parsed.hostname or "").rstrip(".").lower()
    if parsed.scheme.lower() != "https" or not host or parsed.username or parsed.password:
        raise UpdateError("only credential-free HTTPS URLs are accepted")
    if host == "localhost" or host.endswith((".localhost", ".local", ".onion", ".internal")):
        raise UpdateError("local, special-use, and internal hosts are not valid update sources")
    credential_like = {"token", "access_token", "api_key", "apikey", "key", "password", "passwd", "secret", "auth", "signature", "sig", "x-amz-signature"}
    query_names = {key.casefold() for key, _ in urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)}
    if query_names & credential_like:
        raise UpdateError("credential-bearing query parameters are not allowed in update URLs")
    try:
        address = ipaddress.ip_address(host)
        if address.is_private or address.is_loopback or address.is_link_local or address.is_reserved or address.is_unspecified:
            raise UpdateError("private, loopback, link-local, or reserved IP update sources are forbidden")
    except ValueError:
        pass
    return parsed


class HTTPSOnlyRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        validate_https_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def fetch_https(url: str, limit: int = MAX_FILE_BYTES, timeout: float = 15.0) -> bytes:
    validate_https_url(url)
    opener = urllib.request.build_opener(HTTPSOnlyRedirectHandler())
    request = urllib.request.Request(url, headers={"User-Agent": "UniversalToolkit/0.1 (verified-data-updater)"})
    try:
        with opener.open(request, timeout=timeout) as response:
            final = urllib.parse.urlsplit(response.geturl())
            if final.scheme.lower() != "https":
                raise UpdateError("final URL is not HTTPS")
            length = response.headers.get("Content-Length")
            if length:
                try:
                    if int(length) > limit: raise UpdateError("download exceeds configured size limit")
                except ValueError: pass
            data = response.read(limit + 1)
    except UpdateError:
        raise
    except Exception as exc:
        raise UpdateError(f"download failed: {type(exc).__name__}: {exc}") from exc
    if len(data) > limit:
        raise UpdateError("download exceeds configured size limit")
    return data


def validate_manifest(value: dict) -> list[dict]:
    if not isinstance(value, dict) or value.get("schema_version") != 1:
        raise UpdateError("manifest must be an object with schema_version=1")
    version = value.get("version")
    if not isinstance(version, str) or not version.strip() or len(version) > 64:
        raise UpdateError("manifest version is missing or invalid")
    files = value.get("files")
    if not isinstance(files, list) or len(files) > 500:
        raise UpdateError("manifest files must be a list with at most 500 entries")
    output, seen = [], set()
    for entry in files:
        if not isinstance(entry, dict): raise UpdateError("each file entry must be an object")
        path = entry.get("path")
        # Validate path using the shared validator without relying on host-specific paths.
        from .paths import checked_relative_path
        try: checked_relative_path(path)
        except (UnsafePathError, TypeError) as exc: raise UpdateError(f"unsafe path: {path!r}") from exc
        if path in seen: raise UpdateError(f"duplicate path in manifest: {path}")
        seen.add(path)
        op = entry.get("operation", "install")
        if op not in {"install", "remove"}: raise UpdateError(f"unsupported operation: {op}")
        feature = entry.get("feature", "")
        if not isinstance(feature, str) or not FEATURE.fullmatch(feature): raise UpdateError("invalid feature id")
        if op == "install":
            url = entry.get("url")
            try:
                validate_https_url(url)
            except UpdateError as exc:
                raise UpdateError(f"install URL must be a public credential-free HTTPS source: {path}: {exc}") from exc
            if not isinstance(entry.get("sha256"), str) or not HEX64.fullmatch(entry["sha256"]):
                raise UpdateError(f"install entry requires a SHA-256 digest: {path}")
            entry = dict(entry); entry["sha256"] = entry["sha256"].lower()
        else:
            prior = entry.get("previous_sha256")
            if prior is not None and (not isinstance(prior,str) or not HEX64.fullmatch(prior)):
                raise UpdateError(f"invalid previous_sha256 for removal: {path}")
            entry = dict(entry)
            if prior: entry["previous_sha256"] = prior.lower()
        entry["operation"] = op
        output.append(entry)
    return output


def _load_installed(state_dir: Path) -> dict:
    state = read_json(state_dir / "installed.json", {"schema_version":1,"files":[]})
    if not isinstance(state, dict) or not isinstance(state.get("files"), list):
        raise UpdateError("installed state is malformed; do not overwrite it automatically")
    result = {}
    for item in state["files"]:
        if isinstance(item, dict) and isinstance(item.get("path"),str):
            result[item["path"]] = item
    return result


def _backup_path(txn_dir: Path, relative: str) -> Path:
    # Backup paths are nested under transaction directory and revalidated.
    return safe_join(txn_dir / "files", relative, create_parents=True)


def _restore(txn_dir: Path, root: Path, state_dir: Path, *, enforce_after: bool) -> None:
    meta_path = txn_dir / "transaction.json"
    meta = read_json(meta_path, None)
    if not isinstance(meta, dict) or meta.get("schema_version") != 1:
        raise UpdateError("transaction backup metadata is missing or invalid")
    managed = root / "managed"
    # Verify all current contents before making any rollback change.
    if enforce_after:
        conflicts=[]
        for change in meta.get("changes",[]):
            target=safe_join(managed, change["path"])
            exists=target.exists()
            if change.get("after_exists"):
                if not exists or target.is_symlink() or not target.is_file() or sha256_bytes(target.read_bytes()) != change.get("after_sha256"):
                    conflicts.append(change["path"])
            elif exists:
                conflicts.append(change["path"])
        if conflicts:
            raise UpdateError("rollback stopped because managed files changed since update: " + ", ".join(conflicts))
    for change in reversed(meta.get("changes",[])):
        target=safe_join(managed, change["path"], create_parents=True)
        if change.get("before_exists"):
            backup=txn_dir / "files" / change["backup_rel"]
            if not backup.is_file() or backup.is_symlink():
                raise UpdateError(f"missing backup for {change['path']}")
            payload=backup.read_bytes()
            if sha256_bytes(payload) != change.get("before_sha256"):
                raise UpdateError(f"backup integrity check failed for {change['path']}")
            atomic_write(target,payload)
        else:
            try:
                if target.is_symlink(): raise UpdateError(f"refusing to remove symlink during rollback: {change['path']}")
                target.unlink(missing_ok=True)
            except OSError as exc:
                raise UpdateError(f"could not remove newly installed file {change['path']}: {exc}") from exc
    write_json_atomic(state_dir / "installed.json", {"schema_version":1,"files":meta.get("before_installed",[])})
    meta["rolled_back"] = True
    meta["rolled_back_at"] = datetime.now(timezone.utc).isoformat()
    write_json_atomic(meta_path, meta)


def rollback_latest(root: Path, state_dir: Path) -> str:
    backups=state_dir / "backups"
    if not backups.is_dir(): raise UpdateError("no update backups found")
    candidates=[]
    for p in backups.iterdir():
        if p.is_dir() and (p / "transaction.json").is_file():
            data=read_json(p/"transaction.json",{})
            if data and not data.get("rolled_back",False):
                candidates.append((str(data.get("created_at", "")), p))
    if not candidates: raise UpdateError("no unrolled-back transaction exists")
    txn=max(candidates,key=lambda item:(item[0],item[1].name))[1]
    _restore(txn,root,state_dir,enforce_after=True)
    return txn.name


def apply_manifest(manifest: dict, raw_manifest: bytes, expected_manifest_sha256: str | None,
                   root: Path, state_dir: Path, downloader: Callable[[str,int],bytes] = fetch_https) -> str:
    if not expected_manifest_sha256 or not HEX64.fullmatch(expected_manifest_sha256):
        raise UpdateError("--apply requires a 64-character manifest SHA-256 obtained from a trusted release channel")
    actual_manifest_hash=sha256_bytes(raw_manifest)
    if actual_manifest_hash != expected_manifest_sha256.lower():
        raise UpdateError("manifest SHA-256 does not match the supplied trusted digest")
    entries=validate_manifest(manifest)
    if not entries:
        return "No files to apply; repository state is unchanged."
    managed=root/"managed"
    managed.mkdir(parents=True,exist_ok=True)
    state_dir.mkdir(parents=True,exist_ok=True)
    installed=_load_installed(state_dir)
    current_by_path=dict(installed)
    payloads={}; total=0
    # Validate all preconditions and download every install artifact before touching existing files.
    for item in entries:
        path=item["path"]
        target=safe_join(managed,path)
        if target.exists():
            if target.is_symlink() or not target.is_file(): raise UpdateError(f"managed target is not a regular file: {path}")
            if path not in current_by_path: raise UpdateError(f"refusing to overwrite untracked file: {path}")
            current_hash=sha256_bytes(target.read_bytes())
            if current_hash != current_by_path[path].get("sha256"):
                raise UpdateError(f"managed file was modified outside the updater: {path}")
        elif path in current_by_path:
            # Missing tracked files are safe to repair by reinstall; removal is also an idempotent no-op.
            if item["operation"] == "remove": continue
        if item["operation"] == "remove":
            if path not in current_by_path:
                raise UpdateError(f"refusing to remove a file not owned by this toolkit: {path}")
            if target.exists():
                old_hash=sha256_bytes(target.read_bytes())
                if item.get("previous_sha256") and old_hash != item["previous_sha256"]:
                    raise UpdateError(f"previous_sha256 mismatch for removal: {path}")
        else:
            payload=downloader(item["url"],MAX_FILE_BYTES)
            if not isinstance(payload,bytes): raise UpdateError("downloader must return bytes")
            total += len(payload)
            if len(payload)>MAX_FILE_BYTES or total>MAX_TOTAL_BYTES: raise UpdateError("update payloads exceed configured size limits")
            if sha256_bytes(payload) != item["sha256"]: raise UpdateError(f"payload SHA-256 mismatch: {path}")
            payloads[path]=payload
    # Construct and persist a transaction before any target changes.
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]
    txn_dir=state_dir/'backups'/stamp
    txn_dir.mkdir(parents=True,exist_ok=False)
    before_installed=list(installed.values())
    changes=[]
    for item in entries:
        path=item["path"]
        target=safe_join(managed,path)
        exists=target.exists()
        change={"path":path,"before_exists":exists,"before_sha256":None,"backup_rel":None,
                "after_exists":item["operation"]!="remove","after_sha256":sha256_bytes(payloads[path]) if item["operation"]=="install" else None}
        if exists:
            prior=target.read_bytes()
            change["before_sha256"]=sha256_bytes(prior)
            change["backup_rel"]=path
            bp=_backup_path(txn_dir,path)
            atomic_write(bp,prior)
        if item["operation"]=="remove" and not exists:
            change["after_exists"]=False
        changes.append(change)
    meta={"schema_version":1,"transaction_id":stamp,"manifest_version":manifest.get("version"),
          "created_at":datetime.now(timezone.utc).isoformat(),"rolled_back":False,
          "before_installed":before_installed,"changes":changes}
    write_json_atomic(txn_dir/'transaction.json',meta)
    new_installed=dict(installed)
    try:
        for item in entries:
            path=item["path"]
            target=safe_join(managed,path,create_parents=True)
            if item["operation"]=="remove":
                if target.exists():
                    target.unlink()
                new_installed.pop(path,None)
            else:
                payload=payloads[path]
                atomic_write(target,payload)
                new_installed[path]={"path":path,"feature":item["feature"],"sha256":sha256_bytes(payload),"manifest_version":manifest["version"]}
        ordered=sorted(new_installed.values(),key=lambda x:x["path"])
        write_json_atomic(state_dir/'installed.json',{"schema_version":1,"files":ordered})
    except Exception:
        try: _restore(txn_dir,root,state_dir,enforce_after=False)
        except Exception as rollback_error:
            raise UpdateError(f"apply failed and automatic rollback also failed: {rollback_error}")
        raise
    return f"Applied {len(entries)} managed file operation(s) as transaction {stamp}. No downloaded content was executed."


def dry_run(manifest: dict, root: Path) -> list[str]:
    entries=validate_manifest(manifest)
    managed=root/"managed"
    plan=[]
    for item in entries:
        target=safe_join(managed,item["path"])
        if item["operation"]=="install":
            plan.append(f"INSTALL/UPDATE {item['path']} from HTTPS (SHA-256 required; download not performed)")
        else:
            plan.append(f"REMOVE {item['path']} only if ownership and current hash verify")
    if not plan: plan.append("No operations in manifest; no changes planned.")
    return plan
