"""Command-line interface for Universal Cross-Platform Toolkit."""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import os
import sys
import urllib.parse
from pathlib import Path
from . import __version__
from .platform_info import system_report
from .paths import read_json, write_json_atomic, sha256_bytes
from .updater import UpdateError, fetch_https, validate_manifest, apply_manifest, dry_run, rollback_latest, MAX_MANIFEST_BYTES

PACKAGE_ROOT=Path(__file__).resolve().parent.parent
DATA_ROOT=Path(__file__).resolve().parent/'data'


def default_state_dir() -> Path:
    if os.name=='nt':
        base=os.environ.get('APPDATA') or str(Path.home()/'AppData'/'Roaming')
        return Path(base)/'UniversalToolkit'
    xdg=os.environ.get('XDG_CONFIG_HOME')
    if xdg: return Path(xdg)/'universal-toolkit'
    return Path.home()/'.config'/'universal-toolkit'


def resource_data() -> dict:
    return json.loads((DATA_ROOT/'resources.json').read_text(encoding='utf-8'))


def ext_data() -> dict:
    return json.loads((DATA_ROOT/'extensions-curated.json').read_text(encoding='utf-8'))


def export_bookmarks(fmt: str, output: Path | None) -> str:
    data=resource_data(); records=data['bookmarks']
    if fmt=='json': payload=(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    elif fmt=='csv':
        import io
        buf=io.StringIO(newline='')
        w=csv.DictWriter(buf,fieldnames=['category','name','url','tags']);w.writeheader()
        for b in records: w.writerow({**b,'tags':'; '.join(b.get('tags',[]))})
        payload=buf.getvalue()
    else:
        import html
        lines=['<!DOCTYPE NETSCAPE-Bookmark-file-1>','<TITLE>Universal Learning Bookmarks</TITLE>','<H1>Universal Learning Bookmarks</H1>','<DL><p>']
        cat=None
        for b in records:
            if b['category']!=cat:
                if cat is not None: lines.append('</DL><p>')
                cat=b['category'];lines.extend([f'<DT><H3>{html.escape(cat)}</H3>','<DL><p>'])
            lines.append(f'<DT><A HREF="{html.escape(b["url"],quote=True)}">{html.escape(b["name"])}</A>')
        if cat is not None: lines.append('</DL><p>')
        lines.append('</DL><p>');payload='\n'.join(lines)+'\n'
    if output:
        output.parent.mkdir(parents=True,exist_ok=True);output.write_text(payload,encoding='utf-8',newline='\n')
        return f'Wrote {len(records)} bookmark(s) to {output}'
    sys.stdout.write(payload);return ''


def load_manifest(args) -> tuple[dict,bytes,str|None]:
    if args.manifest_url:
        if not args.manifest_sha256:
            raise UpdateError("remote manifests require --manifest-sha256 (trusted out-of-band digest)")
        raw=fetch_https(args.manifest_url,MAX_MANIFEST_BYTES)
    elif args.manifest:
        raw=Path(args.manifest).read_bytes()
        if len(raw)>MAX_MANIFEST_BYTES: raise UpdateError('manifest too large')
    else:
        raise UpdateError('provide --manifest PATH or --manifest-url HTTPS_URL')
    if args.manifest_sha256 and sha256_bytes(raw)!=args.manifest_sha256.lower():
        raise UpdateError('manifest digest mismatch')
    try: data=json.loads(raw.decode('utf-8'))
    except Exception as exc: raise UpdateError(f'manifest is not valid UTF-8 JSON: {exc}') from exc
    validate_manifest(data)
    return data,raw,args.manifest_sha256


def handle_features(args, state_dir: Path) -> int:
    registry=json.loads((DATA_ROOT/'features.json').read_text(encoding='utf-8'))
    known={x['id']:x for x in registry['features']}
    path=state_dir/'features.json'
    state=read_json(path,{"schema_version":1,"enabled":{x['id']:x['default_enabled'] for x in registry['features']}})
    if not isinstance(state,dict) or not isinstance(state.get('enabled'),dict):
        raise UpdateError('feature state is malformed; refusing automatic replacement')
    for fid in known:
        state['enabled'].setdefault(fid,known[fid]['default_enabled'])
    if args.feature_action=='list':
        print(f"{'STATUS':8} {'ID':24} FEATURE")
        for fid,meta in known.items(): print(f"{'enabled' if state['enabled'].get(fid) else 'disabled':8} {fid:24} {meta['name']}")
        return 0
    fid=args.feature_id
    if fid not in known: raise UpdateError(f'unknown feature id: {fid}')
    state['enabled'][fid]=args.feature_action=='enable'
    write_json_atomic(path,state)
    print(f"{fid}: {'enabled' if state['enabled'][fid] else 'disabled'} (preference only; no system settings changed)")
    return 0


def parser_build():
    parser=argparse.ArgumentParser(prog='ubtoolkit',description='Offline-first, cross-platform toolkit with a fail-safe updater')
    parser.add_argument('--version',action='version',version=f'%(prog)s {__version__}')
    parser.add_argument('--state-dir',default=None,help='override per-user state directory (mostly for tests)')
    sub=parser.add_subparsers(dest='command',required=True)
    sub.add_parser('info',help='print a privacy-conscious system/architecture report')
    bp=sub.add_parser('bookmarks',help='export sanitized resource bookmarks')
    bp.add_argument('--format',choices=['html','csv','json'],default='html');bp.add_argument('--output',type=Path)
    cp=sub.add_parser('catalogue',help='show local resource and extension catalogue counts')
    fp=sub.add_parser('features',help='list or change local feature preferences')
    fp.add_argument('feature_action',choices=['list','enable','disable']);fp.add_argument('feature_id',nargs='?')
    up=sub.add_parser('update',help='check, preview, apply, or roll back a verified manifest')
    mode=up.add_mutually_exclusive_group()
    mode.add_argument('--check',action='store_true',help='validate manifest and report a plan (default)')
    mode.add_argument('--dry-run',action='store_true',help='show intended writes without download or changes')
    mode.add_argument('--apply',action='store_true',help='apply verified payloads; requires --manifest-sha256')
    mode.add_argument('--repair',action='store_true',help='reconcile tracked files from a complete verified manifest; refuses user-modified files')
    mode.add_argument('--rollback',action='store_true',help='roll back most recent transaction if files are unchanged')
    src=up.add_mutually_exclusive_group();src.add_argument('--manifest',help='local JSON manifest path');src.add_argument('--manifest-url',help='HTTPS manifest URL (pin it with --manifest-sha256)')
    up.add_argument('--manifest-sha256',help='trusted SHA-256 for the exact raw manifest bytes')
    up.add_argument('--root',type=Path,default=Path.home()/'.local'/'share'/'universal-toolkit',help='managed installation root')
    un=sub.add_parser('uninstall',help='remove only files recorded as toolkit-managed')
    un.add_argument('--apply',action='store_true',help='perform the removal; without this flag only preview')
    un.add_argument('--root',type=Path,default=Path.home()/'.local'/'share'/'universal-toolkit',help='managed installation root')
    return parser


def main(argv=None) -> int:
    parser=parser_build();args=parser.parse_args(argv)
    state_dir=Path(args.state_dir).expanduser() if args.state_dir else default_state_dir()
    try:
        if args.command=='info':
            print(json.dumps(system_report(),ensure_ascii=False,indent=2));return 0
        if args.command=='bookmarks':
            msg=export_bookmarks(args.format,args.output)
            if msg: print(msg)
            return 0
        if args.command=='catalogue':
            r=resource_data();e=ext_data()
            print(json.dumps({'resources':len(r['bookmarks']),'resource_categories':len({x['category'] for x in r['bookmarks']}),
                              'extension_records':len(e['records']),'extension_snapshot':e['snapshot'],
                              'live_link_checks':'not performed during this build'},indent=2));return 0
        if args.command=='features':
            if args.feature_action!='list' and not args.feature_id: parser.error('feature enable/disable requires FEATURE_ID')
            return handle_features(args,state_dir)
        if args.command=='update':
            if args.rollback:
                print('Rolled back transaction:',rollback_latest(args.root.expanduser(),state_dir));return 0
            manifest,raw,digest=load_manifest(args)
            print(f"Manifest version: {manifest['version']} | files: {len(manifest['files'])} | SHA-256: {sha256_bytes(raw)}")
            if args.apply or args.repair:
                result=apply_manifest(manifest,raw,digest,args.root.expanduser(),state_dir)
                if args.repair: print('Repair/reconciliation complete:',result)
                else: print(result)
                return 0
            for line in dry_run(manifest,args.root.expanduser()): print('PLAN:',line)
            if args.dry_run: print('Dry run complete. No downloads or writes occurred.')
            else: print('Check complete. No downloads or writes occurred.')
            return 0
        if args.command=='uninstall':
            installed=read_json(state_dir/'installed.json',{'schema_version':1,'files':[]})
            records=installed.get('files',[]) if isinstance(installed,dict) else []
            if not records:
                print('No toolkit-managed files are recorded; nothing to remove.');return 0
            print('Managed files that would be removed:')
            for item in records: print(' -',item.get('path','<invalid>'))
            if not args.apply:
                print('Preview only. Add --apply to remove only tracked files; unknown files are never deleted.');return 0
            # A generated removal transaction is explicit user intent; removal still validates ownership and hashes.
            manifest={'schema_version':1,'version':'uninstall-'+__version__,'files':[
                {'path':x['path'],'operation':'remove','feature':x['feature']} for x in records
                if isinstance(x,dict) and x.get('path') and x.get('feature')
            ]}
            raw=(json.dumps(manifest,separators=(',',':'))+'\n').encode()
            print(apply_manifest(manifest,raw,sha256_bytes(raw),args.root.expanduser(),state_dir));return 0
    except (UpdateError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f'ERROR: {exc}',file=sys.stderr);return 2
    return 1

if __name__=='__main__': raise SystemExit(main())
