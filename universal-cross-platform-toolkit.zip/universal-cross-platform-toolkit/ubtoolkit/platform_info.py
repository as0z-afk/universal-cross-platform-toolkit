"""Low-risk platform and architecture detection; does not make system changes."""
from __future__ import annotations
import os
import platform
import shutil
import struct
from pathlib import Path


def detect_os() -> str:
    """Return a normalized OS identifier with best-effort ChromeOS detection."""
    override = os.environ.get("UBT_TARGET_OS", "").strip().lower()
    allowed = {"windows", "linux", "bsd", "macos", "chromeos", "unknown"}
    if override in allowed:
        return override
    system = platform.system().lower()
    # ChromeOS native sessions can expose the milestone marker or lsb-release.
    if Path("/dev/.cros_milestone").exists():
        return "chromeos"
    lsb = Path("/etc/lsb-release")
    try:
        text = lsb.read_text(encoding="utf-8", errors="ignore").lower()
        if "chromeos" in text or "chrome os" in text:
            return "chromeos"
    except OSError:
        pass
    if system == "windows":
        return "windows"
    if system == "darwin":
        return "macos"
    if system == "linux":
        return "linux"
    if "bsd" in system or system in {"freebsd", "openbsd", "netbsd", "dragonfly"}:
        return "bsd"
    return "unknown"


def normalize_arch(machine: str | None = None) -> str:
    raw = (machine if machine is not None else platform.machine()).strip().lower()
    mapping = {
        "amd64": "x86_64", "x64": "x86_64", "x86_64": "x86_64",
        "i386": "i686", "i486": "i686", "i586": "i686", "i686": "i686", "x86": "i686",
        "arm": "arm32", "armv5l": "arm32", "armv6l": "arm32", "armv7l": "arm32", "armv7": "arm32",
        "aarch64": "aarch64", "arm64": "aarch64",
        "ppc64le": "ppc64le", "powerpc64le": "ppc64le", "ppc64": "ppc64",
        "riscv64": "riscv64", "s390x": "s390x",
    }
    return mapping.get(raw, raw or "unknown")


def system_report() -> dict:
    """Return intentionally non-identifying host metadata."""
    commands = {name: bool(shutil.which(name)) for name in (
        "python", "python3", "git", "bash", "pwsh", "powershell", "pkg", "brew", "apt", "dnf", "pacman"
    )}
    return {
        "os": detect_os(),
        "os_release": platform.release(),
        "os_version": platform.version()[:120],
        "architecture": normalize_arch(),
        "python_bits": struct.calcsize("P") * 8,
        "python_version": platform.python_version(),
        "machine_raw": platform.machine()[:80] or "unknown",
        "capability_commands": commands,
        "notes": [
            "Detection is best-effort and does not imply the target can run every feature.",
            "ChromeOS may appear as Linux inside Crostini; UBT_TARGET_OS=chromeos is an explicit hint only.",
            "Architecture labels are normalized names, not CPU feature-level guarantees."
        ],
    }
