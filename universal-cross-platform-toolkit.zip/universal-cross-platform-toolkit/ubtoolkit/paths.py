"""Path validation and atomic filesystem primitives."""
from __future__ import annotations
import hashlib
import json
import os
import tempfile
from pathlib import Path, PurePosixPath


class UnsafePathError(ValueError):
    pass


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def checked_relative_path(raw: str) -> PurePosixPath:
    if not isinstance(raw, str) or not raw or len(raw) > 240:
        raise UnsafePathError("path must be a non-empty relative string under 240 characters")
    if "\\" in raw or "\x00" in raw or any(ord(c) < 32 for c in raw):
        raise UnsafePathError("path contains a backslash or control character")
    raw_parts = raw.split("/")
    if any(part in {"", ".", ".."} for part in raw_parts):
        raise UnsafePathError("empty, dot, and parent path segments are forbidden")
    p = PurePosixPath(raw)
    if p.is_absolute() or raw.startswith("/"):
        raise UnsafePathError("absolute paths are forbidden")
    if any(":" in part for part in p.parts):
        raise UnsafePathError("colon-containing path segments are forbidden")
    if not p.parts or p.parts[0].casefold() in {".git", ".state", "state", "backups"}:
        raise UnsafePathError("path targets a reserved area")
    return p


def safe_join(base: Path, relative: str, *, create_parents: bool = False) -> Path:
    rel = checked_relative_path(relative)
    base = base.resolve()
    candidate = base.joinpath(*rel.parts)
    # Reject every symlink component, including an existing final target.
    cursor = base
    for part in rel.parts:
        cursor = cursor / part
        if cursor.is_symlink():
            raise UnsafePathError(f"symlink components are not allowed: {relative}")
    try:
        candidate.resolve(strict=False).relative_to(base)
    except ValueError as exc:
        raise UnsafePathError("target escapes managed root") from exc
    if create_parents:
        candidate.parent.mkdir(parents=True, exist_ok=True)
        # Re-check after directory creation to reduce symlink-race risk.
        cursor = base
        for part in rel.parts[:-1]:
            cursor = cursor / part
            if cursor.is_symlink():
                raise UnsafePathError(f"symlink parent appeared: {relative}")
    return candidate


def atomic_write(path: Path, data: bytes, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise UnsafePathError(f"refusing to replace symlink: {path}")
    fd, temp_name = tempfile.mkstemp(prefix=".ubt-", suffix=".tmp", dir=str(path.parent))
    temp = Path(temp_name)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        try:
            os.chmod(temp, mode)
        except OSError:
            pass
        os.replace(temp, path)
        try:
            dir_fd = os.open(path.parent, os.O_RDONLY)
            try: os.fsync(dir_fd)
            finally: os.close(dir_fd)
        except OSError:
            pass
    finally:
        try: temp.unlink()
        except FileNotFoundError: pass


def read_json(path: Path, default):
    try:
        with path.open("r", encoding="utf-8") as stream:
            value = json.load(stream)
        return value
    except FileNotFoundError:
        return default


def write_json_atomic(path: Path, value) -> None:
    payload = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    atomic_write(path, payload)
