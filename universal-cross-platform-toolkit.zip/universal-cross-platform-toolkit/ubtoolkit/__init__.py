"""Universal Cross-Platform Toolkit: safe, offline-first utilities."""
__version__ = "0.1.0"
