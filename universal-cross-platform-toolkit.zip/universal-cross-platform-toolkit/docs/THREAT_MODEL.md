# Threat Model

## Assets
User files and profiles, browser session/authentication state, integrity of installed feature files, update/rollback state, local preferences, and trust in the curated directory.

## Adversaries / failure cases
Malicious or compromised update server; tampered manifest or payload; URL redirects; zip/path traversal; symlink attacks; unexpected file modification; network interruption; partial disk writes; malformed JSON; oversized responses; unsupported target; denied permissions; low disk space; accidental uninstall; stale catalogue entries.

## Controls
- HTTPS-only update URLs and redirects; no embedded credentials.
- Caller-provided manifest digest required for apply; per-file SHA-256 checks; bounded manifest/file/total sizes.
- Exact relative-path validation; no absolute paths, `..`, backslash traversal, reserved state paths or symlink components.
- Managed-root confinement; unknown file overwrite/removal denied.
- Downloads validated before writes; transaction backups; atomic replacement where available; rollback verifies current contents before restoring.
- No shell-outs for downloads; no remote-code execution; no automatic privileged actions.
- Offline UI has no fetch/CDN/telemetry dependencies.
- Browser focus filter is disabled by default and uses explicit local controls.

## Residual risks
A compromised trusted distribution channel could publish a malicious manifest and its matching digest. Hostname checks reject literal private/reserved IPs and common local/special-use suffixes but do not pin DNS resolution to a public IP; constrain update egress locally if the threat model requires SSRF resistance. SHA-256 is not a publisher signature; retrieve the digest independently or add a proper release-signature system before public automated update infrastructure. A malicious local account/process can race file operations; the tool is not a privilege boundary. Browser DOM selectors and labels can change. URL syntax validation does not prove a link's live status or trustworthiness.

## Out of scope
Root/system optimization, driver/firmware changes, automatic browser profile editing, cookie injection, paywall circumvention, content moderation enforcement, code signing key management, remote administration and exploitation of platform-specific access controls.
