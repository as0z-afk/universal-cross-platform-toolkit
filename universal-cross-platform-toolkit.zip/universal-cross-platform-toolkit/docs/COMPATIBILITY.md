# Compatibility and Support Matrix

**Status labels:** `implemented` means code path exists; `sandbox-tested` means executed in this build environment; `not-run` means no claim of execution; `limited` means environment/security model imposes constraints.

| OS family | Detection | Python CLI (3.10+) | Offline HTML | Managed updater | Status in this build |
|---|---|---|---|---|---|
| Windows 10/11 | implemented | implemented, not-run here | browser-dependent | implemented with stdlib atomic replacement fallback | not-run |
| Linux | implemented | implemented | implemented | implemented | sandbox-tested on current host only |
| FreeBSD/OpenBSD/NetBSD/DragonFly | normalized as BSD when Python reports BSD | expected if Python 3.10+ is installed | browser-dependent | expected; filesystem semantics may vary | not-run |
| macOS | implemented | expected with Python 3.10+ | Safari/Chrome/Firefox current browser | expected; permissions may limit writes | not-run |
| ChromeOS native | marker/lsb-release best effort | depends on environment restrictions | browser-dependent | limited by filesystem/profile restrictions | not-run |
| ChromeOS Crostini | may appear as Linux | works within Linux container if Python available | browser-dependent | affects only container-managed directory | not-run |

| Architecture reported | Normalization | Notes |
|---|---|---|
| i386/i486/i586/i686/x86 | `i686` | Does not imply every package still provides 32-bit binaries. |
| amd64/x64/x86_64 | `x86_64` | Does not infer x86_64-v2 or other CPU feature levels. |
| arm/armv5l/armv6l/armv7l | `arm32` | ARM32 is not AArch64. |
| arm64/aarch64 | `aarch64` | Binary portability remains distribution/runtime-specific. |
| ppc64le/powerpc64le, ppc64, riscv64, s390x | corresponding normalized names | Detection only; not all runtime features are promised. |

The updater uses only Python's standard library and confines writes to a designated per-user managed directory. Actual filesystem behavior must be tested on each target. CI uses available hosted runners; BSD and ChromeOS require independent manual/VM testing. No cross-architecture test result is claimed for this build.
