# Master Specification — Universal Cross-Platform Toolkit

## Purpose and governing priorities

Build a system-neutral GitHub repository that can be uploaded directly, understood without a network connection, inspected before use, expanded by feature manifests, and recovered after failures. Maintain a modular system-reporting and learning-resource toolkit across Windows, Linux, BSD, macOS and ChromeOS where the host permissions permit it. Normalize architectures including i686/32-bit x86, x86_64/64-bit x86, ARM32, AArch64, ppc64le, ppc64, RISC-V 64 and s390x when reported. Detection is not a guarantee that an untested operating-system/architecture pair works.

Order all work by: **(1) safety and data preservation, (2) portability, (3) deterministic behavior, (4) integrity and reversibility, (5) tests and auditability, (6) features and visual polish, (7) optional integrations.** No quantity or character-count target justifies padding, duplicated content, unsafe automation, or invented test evidence.

## Sequence A — Source ingestion and triage

1. Enumerate every supplied archive and nested archive. Record relevant files, versions, formats, dependencies, license clues, duplicate outputs and provenance.
2. Treat all source code and data as untrusted until reviewed. Distinguish runtime source, curated datasets, generated exports, third-party libraries, cached state and personal exports.
3. Retain only material that advances the toolkit: safe OS/architecture detection, bookmark/resource catalogue, curated browser-extension snapshot, static web UI, optional userscripts, theme assets, updater concepts and useful documentation.
4. Deduplicate resource URLs; require credential-free HTTPS URLs; remove tracking parameters only where they are recognizable analytics identifiers; exclude local/private/special-use hosts and malformed entries.
5. Do not publish browser/search histories, cookies, channel identifiers, subscriptions, private conversation logs, personal paths, device fingerprints, account exports, bundled `.git` history, caches, compiled assets or unrelated source documents.
6. Replace unsafe behavior with a safe equivalent where practical. Do not copy browser flags that weaken TLS, sandboxing, site isolation, safe browsing or IPC-flood protection; do not expose debugging ports, downgrade password storage, inject authentication cookies, bypass paywalls or execute remote scripts.
7. Document what was retained, transformed and excluded. An archive being user-supplied does not automatically make every nested asset redistributable.

## Sequence B — Repository structure and ownership

Use clear root documentation (`README.md`, `LICENSE`, `SECURITY.md`, `CONTRIBUTING.md`, `CHANGELOG.md`) and separate implementation, assets, datasets, schemas, platform notes, tests and CI. Keep code in the `ubtoolkit/` package, with `src/core/` documenting logical core boundaries and `adapters/` explaining per-OS behavior. Store browser scripts in `browser/`, resource exports in `bookmarks/`, the offline site in `web/`, curated datasets in `data/`, default configuration in `config/`, machine-readable validation contracts in `schemas/`, and quality evidence in `docs/`. Provide wrappers for POSIX shell, PowerShell and Windows batch where useful. Keep the runtime dependency-free beyond Python 3.10+ standard library.

Keep one source of truth for resource records, and generate JSON, CSV, Netscape HTML and the static catalogue from it. For packaged Python installs, include required data files in package data and smoke-test execution outside the checkout. Never check in local state, secret files, caches or the updater's managed directory.

## Sequence C — Platform discovery and capability boundaries

1. Detect OS using reliable runtime signals, with a documented explicit hint only where host/container ambiguity exists.
2. Normalize architecture aliases without conflating ARM32 with AArch64, x86_64 with i686, or architecture labels with CPU feature levels such as x86_64-v2.
3. Report process bitness separately from the architecture identifier. Do not collect serial numbers, precise hardware fingerprints, user names, home paths or browser profile contents.
4. Probe capabilities rather than assuming package managers, shells, GNU utilities, systemd, Wayland, a display server or default filesystem paths.
5. Unsupported environments must fail clearly and safely. ChromeOS native may differ from a Crostini Linux container; document that distinction and avoid host configuration changes from the container.
6. Do not run OS tune-ups, package installs, browser preference edits, registry writes, privileged commands or profile operations automatically. New adapters require their own threat review, consent flow, backup/rollback plan and target-platform tests.

## Sequence D — Resource catalogue and browser assets

Keep a sourced resource index across AI and programming, formal/informal education, STEM, medicine/neuroscience, cybersecurity, research/consensus, finance/economics, governance/politics, religion/philosophy, history/literature/art/design, craftsmanship and productivity. Store category, display name, HTTPS URL and tags. A listing is a discovery aid, not an endorsement or guarantee of no-login access. Avoid false “verified live” claims unless a dated check actually occurred.

Retain the 2026-10-24 extension-catalogue snapshot as historical data with its captured permission, publisher, rating, update and verification caveats. Marketplace ratings and badges are not a security audit. Do not imply that a Chrome extension rating represents native Brave/Safari/Firefox support.

Generate pure Netscape bookmark HTML without browser-specific metadata, plus JSON/CSV. Maintain responsive offline HTML/CSS/JS with a minimal sticky header, grid spacing, safe-area and `100dvh` support, keyboard controls, reduced-motion handling, live result counts, debounced search (~220 ms), and 100-item pagination for catalogues up to 10,000 records. The current dataset is smaller but the UI design must not hardcode its current length. Use the theme `#060a08` background, `#dce8d8` text, `#1aa88a` teal and `#b8d070` lime. Use a system font stack and inline assets; do not require CDNs, external fonts, remote JSON, analytics or telemetry. External websites are opened only when a user clicks a link.

Optional browser scripts must have narrow match scopes, explicit user controls, minimal storage, a way to undo changes and a clear uninstall path. The focus filter starts disabled for title-keyword filtering and can hide/restore cards and toggle Shorts. A search-assistant button must never auto-redirect or send the query until the user clicks it. A userscript cannot claim to control remote ranking algorithms or act as a network-level blocker.

## Sequence E — Feature and update protocol

Support controlled add/update/remove operations through a versioned JSON manifest. Every entry has a unique, safe relative target path and feature identifier. Install entries require HTTPS URL and SHA-256; remove entries may include an expected previous digest. Reject malformed schema, duplicate paths, credentials in URLs, non-HTTPS redirects, literal private/reserved IPs and common local/special-use hostnames, excessive file counts/sizes and unsafe path segments. DNS rebinding and enterprise-private DNS are residual network-policy concerns.

The exact manifest bytes must match a digest obtained from an independent trusted release channel before apply. HTTPS and hashes help with transport integrity only when the expected digest is trustworthy; they do not constitute publisher identity or a digital signature. Never claim a publisher signature where none exists.

Stage downloads before modifying targets, enforce per-file and total size limits, compare each payload digest, confine all writes to the toolkit-owned `managed/` directory, reject symlinks and non-regular targets, and refuse to overwrite untracked or user-modified files. Make updates idempotent. Back up prior files and ownership state; use atomic replacement where possible; update state only after successful file operations. On failure, restore the prior state automatically where possible. Rollback must compare current files with the transaction's post-update digests and stop rather than overwrite intervening user edits. Removal and uninstall affect only tracked files; never recursively wipe unknown directories or delete browser profiles.

Provide clear `--check`, `--dry-run`, `--apply`, `--rollback`, `--repair` and `uninstall` preview/apply behavior. `--repair` requires a complete trusted manifest and refuses to replace user-modified files. A manifest may add or remove data features, but downloaded payloads are never executed and the updater cannot silently self-modify the running Python package. Remote manifest support must use HTTPS and independent manifest-digest pinning.

## Sequence F — Validation and sandbox gates

1. Parse JSON and schema inputs, lint/compile Python and JavaScript, and run an offline repository audit.
2. Unit-test architecture aliases, path traversal, reserved paths, symlink refusal, manifest structure, unique paths, untrusted URLs, digest mismatch, size bounds, unknown-file protection, install/update/remove, idempotence, interrupted apply, backup integrity and rollback.
3. Simulate invalid URLs/hashes, missing permissions, low space, failed downloads, unsupported platforms, cancellation and user edits inside a disposable temporary directory. Never test destructive operations on the developer's real home or browser profile.
4. Check standalone web behavior: no external resources/network APIs on load, no unsafe HTML injection, keyboard access, responsive layout, reduced motion, pagination, local preference fallback and clear empty/error state.
5. Run CI on available Windows, Linux and macOS runners; mark BSD/ChromeOS and architecture combinations as untested until real environments validate them.
6. Build/install the package into a separate target directory and run its CLI to prove package data is available outside the source checkout.
7. Rebuild `MANIFEST.json`, verify file hashes, audit the final file list, create a ZIP, compute an archive SHA-256 and retain a test report.

## Sequence G — Release contract

A release archive must contain source, code/data licensing notes, asset provenance, feature registry, updater schema/example, OS compatibility matrix, security/threat model, usage/rollback instructions, hashes and actual test results. Clearly identify preview/unverified targets. Do not invent live-link checks, signatures, sandbox outcomes or cross-platform compatibility results. Publish only after gates pass; otherwise label it a preview and report blockers.

## Current implementation boundary

The current repository implements read-only system reporting, packaged resource/extension data, an offline catalogue, pure bookmark exports, user preference controls, optional browser helpers, a hash-pinned managed-data updater, backups, guarded rollback and an uninstall preview. It does not perform privileged OS tuning or browser flag changes. Links were syntax-checked but not live-rechecked. Local unit tests and package smoke tests ran in the build environment only; Windows/macOS/BSD/ChromeOS and non-host CPU architectures remain unverified. See `docs/TEST_REPORT.md` and `docs/COMPATIBILITY.md`.
