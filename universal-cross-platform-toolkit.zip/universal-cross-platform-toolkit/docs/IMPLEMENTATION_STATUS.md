# Requirement-to-Implementation Traceability

| Requirement | Location | Status / limitation |
|---|---|---|
| Fresh repository with clear modular tree | root README, `ubtoolkit/`, `src/core/`, `adapters/`, `docs/` | Implemented; maintained as preview. |
| OS / architecture detection | `ubtoolkit/platform_info.py` | Unit-tested on current host; other operating systems not run. |
| Windows/Linux/BSD/macOS/ChromeOS notes | `adapters/*/README.md`, `docs/COMPATIBILITY.md` | Documented; no unsupported mutator silently runs. |
| ARM32/AArch64/i686/x86_64 and additional aliases | `normalize_arch`, tests | Unit-tested using representative strings; not actual CPU cross-testing. |
| Safe update manifest and features | `ubtoolkit/updater.py`, `schemas/update-manifest.schema.json` | Implemented for managed data files only; publisher signatures not built in. |
| Integrity/pinning | manifest and payload SHA-256; HTTPS-only source/redirect plus literal-private/local-host checks | Implemented; digest must arrive via trusted independent channel; DNS-address policy is a residual risk. |
| Backups and rollback | transaction folders under user state directory | Unit-tested in temp sandboxes; host filesystem matrices not tested. |
| Add/remove features | update `operation` install/remove; feature preference commands | Implemented for tracked managed data and local preference values; never executes payloads. |
| `--check`, `--dry-run`, `--apply`, `--rollback`, `--repair` | CLI `update` subcommand | Implemented; repair requires a complete verified manifest and does not overwrite edited files. |
| Uninstaller/fail-safe | `ubtoolkit/cli.py` | Preview by default; `--apply` affects tracked files only. |
| Offline resource/browser extension catalogue | `web/index.html`, `data/*.json` | Implemented with 244 resources/28 categories and 40 historical extension records. |
| Bookmark output formats | `bookmarks/`, `ubtoolkit bookmarks` | Implemented: Netscape HTML, JSON and CSV. |
| Low-resource, responsive teal-lime UI | `web/index.html`, inline SVG | Implemented; manual assistive-tech/browser matrix not yet run. |
| Optional user scripts | `browser/*.user.js` | Implemented; manual browser-site compatibility not run; both are optional. |
| Remove unsafe flags/cookie injection/paywall bypass | exclusions documented in provenance/security docs | Unsafe original material not carried forward. |
| CI and automated tests | `.github/workflows/tests.yml`, `tests/` | CI configured; current-host tests were run locally. Hosted CI has not yet run for this generated archive. |
| Source hashes | `MANIFEST.json`, `scripts/build_manifest.py` | Generated during release packaging; manifest excludes itself. |
| Live resource link verification | N/A | Not performed. URLs are syntax-checked only. |
| One million characters of generated source | N/A | Not padded to an arbitrary size; coherent modular code and traceability take priority. |
