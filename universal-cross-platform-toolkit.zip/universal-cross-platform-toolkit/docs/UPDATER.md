# Managed Updater Protocol

## Manifest
`schema_version` must be `1`; `version` is a short release label; `files` contains up to 500 unique relative paths. An `install` entry requires a feature ID, credential-free HTTPS URL and 64-character SHA-256 digest. A `remove` entry requires a feature ID and may declare `previous_sha256`. Every payload is treated as data; no file is executed. See `schemas/update-manifest.schema.json`.

## Flow
1. Read local manifest, or fetch a remote manifest from HTTPS with an externally trusted SHA-256 pin.
2. Validate JSON/schema/paths/operations/HTTPS URLs/digests and reject duplicates.
3. For apply, verify exact raw-manifest SHA-256 against `--manifest-sha256`.
4. Download all install payloads with redirects restricted to HTTPS; limit each file to 10 MiB and total payloads to 25 MiB. Verify all payload hashes before mutating the managed root.
5. Refuse untracked overwrites/removals, symlinks, non-regular targets, or content that diverges from installed state.
6. Back up prior bytes; write new data atomically; save owned-file state only after changes. A failure attempts immediate restoration.
7. Rollback verifies that current files are identical to the transaction's post-update state; if someone edited them, rollback stops rather than destroying newer work.
8. Removal only touches files owned by the toolkit. Unknown files are never recursively deleted.

## Example commands
```sh
python -m ubtoolkit update --manifest data/update-manifest.example.json --check
python -m ubtoolkit update --manifest data/update-manifest.example.json --dry-run
python -m ubtoolkit update --manifest release.json --manifest-sha256 <trusted-64-hex-digest> --apply
python -m ubtoolkit update --manifest complete-repair.json --manifest-sha256 <trusted-64-hex-digest> --repair
python -m ubtoolkit update --rollback
python -m ubtoolkit uninstall
python -m ubtoolkit uninstall --apply
```

`--repair` requires a complete, trusted manifest. It restores missing managed files and reconciles files that are already present and unchanged; it refuses modified or untracked files instead of overwriting them. The included example manifest contains no payloads. Do not deploy a public updater until a maintainers' release channel publishes manifests, payload digests, an independent digest/signature mechanism, release notes and tested rollback results. A SHA-256 digest copied from the same untrusted page as a manifest provides no independent authenticity.
