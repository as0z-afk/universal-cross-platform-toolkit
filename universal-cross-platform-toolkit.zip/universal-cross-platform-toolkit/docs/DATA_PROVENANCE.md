# Data Provenance and Exclusions

## Retained
- `data/resources.json` and `bookmarks/`: derived from `unuo.zip` → `universal_bookmarks_final.json`, supplied by the user. Source declared 244 records and 28 categories; this build retained **244** syntactically valid unique HTTPS URLs across **28** categories after normalization/deduplication. Links were not live-checked; labels, account requirements, availability and service claims may be stale.
- `data/extensions-curated.json`: derived from `browser extension.zip` → curated extension catalogue dated 2026-10-24, containing **40** platform records. Historical ratings/update markers were not rechecked. The original snapshot itself notes unverified fields and that store signals are not a security audit.
- `browser/youtube-focus-filter.user.js`: newly written, opt-in and reversible. It is not the source archive's paywall-bypass script.
- The colors and general layout direction are adapted from the user-supplied catalogue: dark green-black `#060a08`, cream `#dce8d8`, teal `#1aa88a`, lime `#b8d070`.

## Excluded intentionally
- Browser and search history HTML, watch-history exports, user-specific channel/playlists/subscription exports and conversation logs.
- Machine model, firmware, kernel, home-directory paths, browser-profile paths and system-specific fingerprints embedded in old scripts.
- Browser command-line flags that weaken sandbox/TLS/site isolation/safe browsing, expose remote debugging, disable IPC-flood protection, or use basic password storage.
- Authentication-cookie injection, credential material and the broad-match paywall-bypass reader script.
- Nested `.git` repositories, bundled Python libraries, caches, browser config directories, third-party compiled assets, large source PDFs and unrelated prompt libraries.

## Licensing note
The MIT license covers newly written code in this repository only. Curated resource URLs and extension records are based on user-supplied material; upstream names/logos belong to their respective owners and any non-code rights in the source files were not independently verified. Review item-level rights before commercial redistribution. The included SVG is original simple artwork.
