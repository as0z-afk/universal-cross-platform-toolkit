# Master Prompt: Universal Cross-Platform GitHub Toolkit

Act as a systems/security engineer and release maintainer. Inspect the ZIP and nested archives; treat code as untrusted. Inventory assets, dependencies, licenses, conflicts, duplicates and private data. Build an upload-ready repository. Mark requirements implemented, safely adapted, unsupported or unverified; never invent URLs or test results.

## 1. Goal
Build system discovery, optional low-resource tuning, browser setup, English-learning resources, bookmarks and user-controlled filters. Target Windows, Linux, BSD, macOS and ChromeOS where allowed; i686, x86_64, ARM/armv7 where feasible, AArch64 and ppc64le. State limits; prioritize safety, portability and rollback; keep the core offline.

## 2. Archive and privacy
Reuse relevant assets: system script/OS-architecture detection; browser settings/userscripts and content rules; search/reader helper; bookmark exports; full-screen catalogue and teal-lime theme; JSON descriptor using an embedder/module loader, never `eval`; updater/provenance/license records. Reconcile versions and omit unrelated items. Never publish private histories, account IDs, cookies, tokens, credentials, local paths or metadata; use synthetic data. No paywall, DRM or access-control bypass.

## 3. Repository
Include README/LICENSE/SECURITY/CONTRIBUTING/CHANGELOG; `docs/`, `src/core/`, per-OS `adapters/`, `browser/`, `bookmarks/`, `web/`, `integrations/`, licensed `assets/`, `schemas/`, `config/`, `scripts/`, `tests/`, `.github/workflows/` and `MANIFEST.json`. Document architecture, threat model, setup, compatibility, rollback and provenance. Manifest sources, hashes, licenses, dependencies and test state. 

## 4. Portability and safety
Detect OS, shell, architecture/bitness, permissions, package manager, browser/version and capabilities. Normalize x86/ARM aliases; never confuse ARM32/AArch64 or infer x86_64-v2 by name. Use capability probes; don't assume GNU tools, Linux paths, systemd, apt or Wayland. BSD/ChromeOS must document limits and safely no-op if unsupported.

Default to read-only, `--dry-run`, least privilege, opt-in, diffs and backups. Validate settings per OS/app; skip unknown flags. Tune conservatively and measure. Never disable certificate validation, sandbox, site isolation, web security, safe browsing or IPC-flood protection; never expose debug ports, store passwords insecurely, run remote code directly or overwrite profiles. Remove unsafe flags or mark lab-only.

## 5. Resources, bookmarks and filters
Maintain a sourced resource dataset for education/research, STEM/medicine, cybersecurity, AI, business/finance, governance, religion/philosophy, arts/history, crafts and productivity, including regional English-primary AI tools. Verify access claims. Deduplicate URLs, safely strip tracking, exclude malformed/synthetic/private/local/`.onion` and broken links; recheck updates and distinguish authentic 403/429. Generate strict Netscape HTML and JSON/CSV/JS from one source.

Provide reversible filters for clickbait, scams, pseudoscience, low-grade content, gossip/drama, vulgarity and roasting without blocking legitimate education, politics, medicine, culture or art. Explain blocks, allow overrides, and don't classify all non-ASCII as non-English. Optional YouTube settings hide home/trending/Shorts, end cards, ads/merch and autoplay while retaining search, subscriptions, channels, player and playlists. Never claim control of remote algorithms.

## 6. UI
Build responsive offline HTML/CSS/JS with minimal topbar, keyboard support, reduced motion and clear errors. Use `#060a08`, `#dce8d8`, `#1aa88a`, `#b8d070`; target WCAG AA. Support safe areas, `100dvh` fallback, grid gaps, ~220ms search debounce and 100-item pagination up to 10,000 records. Keep preferences local; no default analytics/uploads.

## 7. Updater and fail-safe
Use versioned manifests/changelogs, compatibility checks, trusted sources, hashes/signatures where feasible, staged downloads, atomic writes, backups and rollback. Validate every feature change; never auto-run remote code. Show source/hash/permissions/impact and confirm privileged changes. On integrity/health failure, interruption, unsupported target or missing/denied dependency, stop and recover without data loss. Make updates idempotent; never delete unknown files. Include offline mode and `--check`, `--dry-run`, `--apply`, `--rollback`, `--repair`, `--uninstall`.

List `https://massgrave.dev/` and `https://github.com/massgravel/Microsoft-Activation-Scripts` as opt-in third-party licensing references only. Never embed, mirror, download or auto-run activation payloads; link upstream documentation and legitimate licensing options outside the core updater.

## 8. Build/test sequence
1. Inventory, source audit, threat model and acceptance checklist. 2. Design tree/adapters/schemas. 3. Build detection, dry-run, backup and rollback first. 4. Add features. 5. Unit-test URLs, schemas, paths, permissions, rollback and idempotence. 6. Run syntax/lint/static, license/dependency and security checks. 7. Offline sandbox tests for bad files/hashes, failed downloads, unsupported targets, denied permissions, low disk, cancellation, partial writes and rollback; never destructively test host. 8. CI on available OS/architectures; mark untested targets. 9. Verify accessibility, exports, URLs/licenses and resource use. 10. Package ZIP, hashes, manifest, recovery docs, logs, limitations and release checklist. Release only if gates pass; otherwise mark preview.

## 9. Deliverable
Deliver ZIP/repository, tree, OS setup, compatibility matrix, source/license manifest, test report, limitations and rollback guide. Never claim unrun tests. Target up to ~1,000,000 useful characters across coherent code/docs/tests, prioritized by risk, compatibility, reliability and dependencies. Maintain a checklist; no padding, duplication, invented evidence or secrets. Finish secure, reversible and verifiable.
