# Build and Sandbox Test Report

**Build date:** 2026-10-25 (Asia/Dhaka)  
**Package version:** 0.1.0  
**Status:** Preview; local Linux/x86_64 sandbox validated, other platforms remain unverified.

## Executed checks

| Check | Result | Evidence / limit |
|---|---|---|
| Repository audit | PASS | `python scripts/audit_repo.py`; validates JSON, unique HTTPS resource URLs, packaged-data sync, offline-site request patterns, and absence of selected unsafe patterns in executable code. |
| Unit tests | PASS | `python -m unittest discover -s tests -v`; **28 tests passed** in the final unit run. |
| CLI system report | PASS | `python -m ubtoolkit info` ran on the build host. |
| CLI data catalogue | PASS | Reported 244 learning-resource records across 28 categories and 40 browser-extension records, snapshot 2026-10-24. |
| Example manifest check | PASS | `python -m ubtoolkit update --manifest data/update-manifest.example.json --check`; no downloads or writes. |
| Feature registry | PASS | `python -m ubtoolkit features list`; returned known features with local defaults. |
| Python package build | PASS | Built and installed the current wheel (`universal_cross_platform_toolkit-0.1.0-py3-none-any.whl`, 29,692 bytes) with `pip wheel --no-build-isolation --no-deps`; an isolated-target install ran `python -m ubtoolkit catalogue` successfully outside the checkout. |
| Installed-package smoke test | PASS | Ran `python -m ubtoolkit catalogue` outside checkout via the isolated target install; package data resolved. |
| JavaScript syntax | PASS | Node.js `--check` on both userscripts and extracted inline script from `web/index.html`. |
| URL live reachability | NOT RUN | No 244/40 URL network sweep was performed. Data is syntactically checked only. |
| Windows/macOS/BSD/ChromeOS | NOT RUN | CI workflow is configured for hosted Windows/Linux/macOS; that hosted CI has not run from this generated release. BSD/ChromeOS need separate environments. |
| Non-host CPU architectures | NOT RUN | Architecture alias unit tests are not cross-architecture runtime tests. |
| Manual accessibility/browser interaction | NOT RUN | DOM/keyboard/assistive-technology QA must be completed in actual browsers before stable release. |

## Sandbox coverage

The unit suite exercises valid/invalid architecture aliases; separation of ARM32 and AArch64; relative-path and reserved-path rejection; symlink rejection where available; atomic writes; installed/removed managed files; payload and manifest hash mismatches; unknown-file preservation; private update-host rejection; duplicate paths; rollback after install/update; rollback refusal after user edits; and resource/catalogue schema caveats.

All updater tests use temporary directories and synthetic payloads. No test applied system settings, altered a real browser profile, contacted an update server, or ran a downloaded payload.

## Release decision

**Do not label this package production-stable yet.** The local core has passed its scripted tests, but real OS/architecture matrix testing, hosted CI, manual browser accessibility checks, independent release digest/signature publication and any necessary link review remain release gates.
