# Third-Party Boundaries

The user-provided project materials referenced these external resources:

- https://massgrave.dev/
- https://github.com/massgravel/Microsoft-Activation-Scripts

They are informational links only and are not included in the runtime or updater. This repository does not download, embed, mirror, launch, or automate activation payloads. Use software vendor documentation and valid licenses for activation and deployment. More broadly, this toolkit never treats a URL as an instruction to execute remote code.
