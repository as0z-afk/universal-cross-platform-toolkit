# Sandbox Test Procedure and Results

## Automated suite
Run: `python -m unittest discover -s tests -v`. All updater writes in unit tests occur under temporary directories. Tests should never target the host's real home or browser profile.

## Required release sandbox cases
- Corrupt manifest digest and corrupt payload digest.
- HTTP URL and HTTPS-to-HTTP redirect attempts.
- Absolute path, `..`, drive-letter, backslash, reserved-directory and symlink path attempts.
- Duplicate path, wrong schema, malformed JSON and oversize manifest/file/total payload.
- Failed download before writes; denied permissions; low disk; interrupted atomic write.
- New install, managed update, managed removal, and rollback.
- Rollback after user-edited installed file must refuse to overwrite it.
- Unknown file overwrite/remove must be refused; unknown files survive uninstall.
- Idempotent repeat of update/remove; interrupted transaction restores prior bytes where possible.
- Static webpage opens from `file://`, search debounce/pagination, keyboard controls, reduced motion and no remote requests.
- Userscript defaults to keyword filter OFF and can restore cards, disable filter or be removed through its manager.

## Actual run status for this generated package
Only tests actually run in the generation environment are reported in the final build report. Windows/macOS/BSD/ChromeOS and non-host architectures must remain `not-run` until run in those environments. This is not a claim of exhaustive predeployment validation.
