# Release Checklist

- [ ] Read the source/provenance report; verify no private uploads, histories, secrets or host paths are included.
- [ ] Run unit tests and security/static checks in a clean disposable workspace.
- [ ] Test with Python 3.10+ on each claimed OS; record exact version and architecture.
- [ ] Inspect and review every proposed update manifest and payload diff.
- [ ] Verify payload SHA-256 values and a manifest digest/signature obtained through an independent trusted channel.
- [ ] Exercise interrupted apply, rollback, modified-file refusal, and uninstall in a disposable managed root.
- [ ] Check extension permissions and browser compatibility separately; do not rely on marketplace ratings alone.
- [ ] Check website accessibility, offline behavior, keyboard navigation, reduced-motion mode, and absence of external requests.
- [ ] Regenerate `MANIFEST.json`, verify checksums, and record archive hash.
- [ ] Publish limitations and untested platform/architecture combinations; do not promote preview to stable unless all release gates pass.
